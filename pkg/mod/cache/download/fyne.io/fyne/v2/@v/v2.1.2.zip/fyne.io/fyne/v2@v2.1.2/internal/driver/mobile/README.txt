This directory is a fork of the golang.org/x/mobile package. It has largely
deviated from the original package to better support fyne.

The full project, its license can be found at https://github.com/golang/mobile

This package is for the purpose of removing the dependency of mobile drivers
and will be removed in due course.